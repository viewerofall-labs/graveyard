#!/usr/bin/env bash
# shellcheck disable=SC2034

iso_name="yourmom"
iso_label="YOURMOM_$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y%m)"
iso_publisher="Yo Mama Computing Solutions <https://github.com/viewerofall/yourmom-lang>"
iso_application="YoMom Linux — btw I use yo mama"
iso_version="$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y.%m.%d)-vq3"
install_dir="arch"
buildmodes=('iso')
bootmodes=('bios.syslinux'
           'uefi.systemd-boot')
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'xz' '-Xbcj' 'x86' '-b' '1M' '-Xdict-size' '1M')
bootstrap_tarball_compression=('zstd' '-c' '-T0' '--auto-threads=logical' '--long' '-19')
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/root"]="0:0:750"
  ["/root/.automated_script.sh"]="0:0:755"
  ["/root/.gnupg"]="0:0:700"
  ["/usr/local/bin/choose-mirror"]="0:0:755"
  ["/usr/local/bin/Installation_guide"]="0:0:755"
  ["/usr/local/bin/livecd-sound"]="0:0:755"
  ["/usr/local/bin/join-game"]="0:0:755"
  ["/usr/local/bin/yourmom"]="0:0:755"
  ["/usr/local/bin/mama"]="0:0:755"
  ["/usr/local/bin/dada"]="0:0:755"
  ["/usr/local/bin/yominit"]="0:0:755"
  ["/usr/local/bin/yominit-splash"]="0:0:755"
)
