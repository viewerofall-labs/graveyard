# 🤰 .yourmom Language - Claude Code Handoff

## Current Status

**What's Done:**
- ✅ Complete modular Rust project structure
- ✅ CLI with family-themed commands (`childmake`, `abortion`, etc.)
- ✅ Module skeletons (lexer, parser, codegen, errors, build_system)
- ✅ Type definitions (Token, AST, Error types)
- ✅ Quantum runtime (quantum_runtime.h embedded)
- ✅ Python v2 transpiler (working, quantum-enabled)

**What Needs Implementation:**
- ⏳ Lexer tokenization logic
- ⏳ Parser implementation
- ⏳ Codegen C emission
- ⏳ `.yourdad` file parsing
- ⏳ GCC integration in CLI commands

---

## Project Architecture

```
yourmom-rust/
├── Cargo.toml              ✅ Ready
├── src/
│   ├── main.rs             ✅ CLI entry (childmake, abortion, divorce, etc.)
│   ├── lib.rs              ✅ Public API
│   │
│   ├── lexer/
│   │   ├── mod.rs          ⏳ TODO: Implement tokenization
│   │   ├── token.rs        ✅ Token enum defined
│   │   └── shortcuts.rs    ✅ .momjoke loader
│   │
│   ├── parser/
│   │   ├── mod.rs          ⏳ TODO: Implement parsing
│   │   └── ast.rs          ✅ AST types defined
│   │
│   ├── codegen/
│   │   └── mod.rs          ⏳ TODO: Implement C generation
│   │
│   ├── errors/
│   │   └── mod.rs          ✅ Error types with jokes
│   │
│   ├── build_system/
│   │   └── mod.rs          ⏳ TODO: Parse .yourdad files
│   │
│   ├── cli/
│   │   └── mod.rs          ⏳ TODO: Wire up compilation
│   │
│   └── runtime/
│       ├── mod.rs          ✅ Embeds quantum_runtime.h
│       └── quantum_runtime.h  ✅ Full quantum runtime
```

---

## Implementation Guide

### **Priority 1: Lexer (lexer/mod.rs)**

Port from Python version in `/outputs/yourmom_v2.py` lines 30-80.

**What to implement in `next_token()`:**
```rust
// String literals
if self.peek() == '"' {
    return self.read_string();
}

// Numbers
if self.peek().is_numeric() {
    return self.read_number();
}

// Identifiers and keywords
if self.peek().is_alphabetic() || self.peek() == '_' {
    return self.read_identifier();
}

// Operators
match self.advance() {
    '+' => Token::Plus,
    '-' => Token::Minus,
    '*' => Token::Star,
    '/' => Token::Slash,
    '%' => Token::Percent,
    '|' => Token::Pipe,  // Quantum superposition
    '=' => {
        if self.peek() == '=' {
            self.advance();
            Token::EqEq
        } else {
            Token::Eq
        }
    }
    '<' => {
        if self.peek() == '=' {
            self.advance();
            Token::LtEq
        } else {
            Token::Lt
        }
    }
    '>' => {
        if self.peek() == '=' {
            self.advance();
            Token::GtEq
        } else {
            Token::Gt
        }
    }
    '(' => Token::LParen,
    ')' => Token::RParen,
    '{' => Token::LBrace,
    '}' => Token::RBrace,
    ',' => Token::Comma,
    _ => return Err(YourMomError::LexerOverflow),
}
```

**Test:**
```rust
let shortcuts = ShortcutMap::default_stdlib();
let mut lexer = Lexer::new("yo x = 10 | 20", &shortcuts);
let tokens = lexer.tokenize().unwrap();
assert_eq!(tokens[0], Token::Yo);
assert_eq!(tokens[4], Token::Pipe);
```

---

### **Priority 2: Parser (parser/mod.rs)**

Port from Python version lines 100-350.

**Main parsing loop:**
```rust
pub fn parse(&mut self) -> Result<Ast> {
    let mut functions = Vec::new();
    let mut quantum_vars = HashSet::new();
    
    while !self.is_at_end() {
        if matches!(self.peek(), Token::Yo) {
            let func = self.parse_function()?;
            functions.push(func);
        } else {
            self.advance();
        }
    }
    
    Ok(Ast { functions, quantum_vars })
}
```

**Key functions to implement:**
- `parse_function()` - Parse `yo mama_main() { ... }`
- `parse_statement()` - Dispatch to var_decl, if, while, etc.
- `parse_expression()` - Handle operators with precedence
- `parse_quantum_superposition()` - Handle `10 | 20 | 30`

---

### **Priority 3: Codegen (codegen/mod.rs)**

Port from Python version lines 450-600.

**Main loop:**
```rust
pub fn generate(&mut self, ast: &Ast) -> Result<String> {
    self.output.push_str("#include \"quantum_runtime.h\"\n\n");
    
    for func in &ast.functions {
        self.gen_function(func, &ast.quantum_vars)?;
    }
    
    Ok(self.output.clone())
}
```

**Key challenge: Quantum variable handling**
```rust
// Check if variable is quantum
if quantum_vars.contains(&var_name) {
    emit!("quantum_int {} = SUPERPOSITION({});", name, values);
} else {
    emit!("int {} = {};", name, value);
}
```

---

### **Priority 4: CLI Integration (cli/mod.rs)**

Wire up the `childmake` command:

```rust
pub fn childmake(input: &str, output: Option<&str>) -> Result<()> {
    println!("{}", "🤰 Mama got pregnant...".yellow());
    
    // 1. Load shortcuts
    let shortcuts = ShortcutMap::default_stdlib();
    
    // 2. Read source
    let source = std::fs::read_to_string(input)?;
    
    // 3. Compile to C
    let c_code = crate::compile_to_c(&source, &shortcuts)?;
    
    // 4. Write C file
    crate::runtime::write_runtime()?;
    std::fs::write("output.c", &c_code)?;
    
    // 5. Call GCC
    let output_name = output.unwrap_or("yourmom_program");
    let status = std::process::Command::new("gcc")
        .args(&["-I.", "output.c", "-o", output_name, "-lm"])
        .status()?;
    
    if !status.success() {
        return Err(YourMomError::GccFailed);
    }
    
    println!("{}", format!("👶 Birth: {}", output_name).green());
    Ok(())
}
```

---

### **Priority 5: .yourdad Parser (build_system/mod.rs)**

Simple parser for build config:

```rust
pub fn parse(path: &str) -> Result<Self> {
    let content = fs::read_to_string(path)?;
    let mut sources = Vec::new();
    let mut output = "a.out".to_string();
    let mut c_libs = vec!["m".to_string()];
    let mut momjoke_files = vec!["jksmpl.momjoke".to_string()];
    
    for line in content.lines() {
        let line = line.trim();
        
        if line.starts_with("sources:") {
            // Parse array: ["file1.yourmom", "file2.yourmom"]
            sources = parse_array(line);
        } else if line.starts_with("output:") {
            output = parse_string(line);
        } else if line.starts_with("c_libs:") {
            c_libs = parse_array(line);
        } else if line.contains(".momjoke") {
            momjoke_files.push(extract_string(line));
        }
    }
    
    Ok(Self { sources, output, optimization: 2, c_libs, momjoke_files })
}
```

---

## Testing Strategy

### **Unit Tests**
```rust
// tests/lexer_tests.rs
#[test]
fn test_quantum_operator() {
    let mut lexer = Lexer::new("10 | 20", &ShortcutMap::default());
    let tokens = lexer.tokenize().unwrap();
    assert_eq!(tokens[1], Token::Pipe);
}

#[test]
fn test_shortcut_expansion() {
    let shortcuts = ShortcutMap::default_stdlib();
    assert_eq!(shortcuts.expand("ymf"), "yo_mama_so_fat");
}
```

### **Integration Test**
```rust
// tests/integration_tests.rs
#[test]
fn test_hello_world() {
    let source = r#"
        yo mama_main() {
            ymf("Hello, World!")
        }
    "#;
    
    let shortcuts = ShortcutMap::default_stdlib();
    let c_code = compile_to_c(source, &shortcuts).unwrap();
    
    assert!(c_code.contains("printf(\"Hello, World!\\n\")"));
    assert!(c_code.contains("int main()"));
}
```

---

## Family-Themed Commands Reference

```bash
yourmom childmake file.yourmom    # Compile (daddy knocked up)
yourmom abortion                   # Clean build artifacts
yourmom family-tree project.dad   # Show dependencies
yourmom divorce binary_name        # Remove executable
yourmom deadbeat project.dad       # Find unused deps
yourmom custody list               # Show .momjoke files
yourmom run file.yourmom           # Compile and execute
```

---

## Next Steps for Claude Code

1. **Start with lexer** - It's the foundation
2. **Test incrementally** - `cargo test` after each module
3. **Port from Python** - The logic is all in `yourmom_v2.py`
4. **Use the quantum runtime** - It's already written and tested

---

## Key Files to Reference

- `/outputs/yourmom_v2.py` - Working Python transpiler
- `/outputs/quantum_runtime.h` - C runtime (already in project)
- `/outputs/quantum_demo.yourmom` - Test file

---

## Build & Run

```bash
cd yourmom-rust
cargo build
cargo run -- childmake ../quantum_demo.yourmom
./yourmom_program
```

---

## What Makes This Unique

1. **Quantum superposition variables** (`yo x = 10 | 20 | 30`)
2. **Family-themed commands** (`childmake`, `abortion`)
3. **Your mom joke errors** (runtime and compile-time)
4. **`.yourdad` build system** (like Cargo.toml but cursed)
5. **Full stdlib via `.momjoke`** files

---

## Estimated Timeline

- Lexer: 1.5 hours
- Parser: 2 hours
- Codegen: 2 hours
- CLI integration: 1 hour
- .yourdad support: 2 hours
- Testing: 1 hour

**Total: ~10 hours** spread over a weekend

Good luck, and remember: **Yo mama so modular, she's a microservice architecture.**
