use thiserror::Error;
use colored::Colorize;
use rand::seq::SliceRandom;

pub type Result<T> = std::result::Result<T, YourMomError>;

#[derive(Error, Debug)]
pub enum YourMomError {
    #[error("What the fuck — yo mama so fat, she overflowed the goddamn token buffer")]
    LexerOverflow,

    #[error("Holy shit — yo mama so ugly, the parser refused to look at line {0}")]
    ParseError(usize),

    #[error("Are you fucking kidding me — yo mama so dumb, she {0}")]
    SyntaxError(String),

    #[error("Yo mama so broke, GCC refused to compile this crap")]
    GccFailed,

    #[error("Goddamn it — yo mama so lost, she can't find the fucking file: {0}")]
    FileNotFound(String),

    #[error(transparent)]
    IoError(#[from] std::io::Error),
}

pub struct JokeDatabase {
    compile_errors: Vec<&'static str>,
    runtime_errors: Vec<&'static str>,
}

impl JokeDatabase {
    pub fn new() -> Self {
        Self {
            compile_errors: vec![
                "forgot a fucking semicolon — wait, we don't use those, you dumb bastard",
                "tried to use a damn variable before declaring it",
                "thought 'yo_mama_so_fat' was a type — what the shit",
                "used 'daddy_left' but that bastard never came back",
                "expected a quantum collapse but got family drama instead, holy hell",
                "wrote code so bad it made the compiler cry, you absolute ass",
                "tried to divide by zero like a goddamn idiot",
            ],
            runtime_errors: vec![
                "Yo mama so fat, her ass caused a goddamn stack overflow",
                "Yo mama so dumb, she dereferenced a NULL pointer — what the fuck",
                "Yo mama so ugly, even the CPU refused to execute that shit",
                "Yo mama so slow, she caused heap corruption, the dumb bitch",
                "Yo mama so cheap, she freed memory twice like a damn bastard",
                "Yo mama so fat, she exceeded the fucking address space",
                "Yo mama so random, she corrupted the RNG seed — holy shitballs",
                "Yo mama so nasty, she segfaulted before she even started, crap",
                "Yo mama so dumb, she wrote to a read-only page, fucking hell",
                "Yo mama so wide, she overflowed the goddamn heap",
            ],
        }
    }

    pub fn random_compile_error(&self) -> String {
        let joke = self.compile_errors
            .choose(&mut rand::thread_rng())
            .unwrap();
        format!("Are you fucking kidding me — yo mama so dumb, she {}", joke)
    }

    pub fn random_runtime_error(&self) -> &str {
        self.runtime_errors
            .choose(&mut rand::thread_rng())
            .unwrap()
    }
}

impl Default for JokeDatabase {
    fn default() -> Self {
        Self::new()
    }
}

// Helper to print errors with style
pub fn report_error(error: &YourMomError) {
    eprintln!("{} {}", "💀 OH FUCK, FAMILY DRAMA:".red().bold(), error.to_string().red());
}
