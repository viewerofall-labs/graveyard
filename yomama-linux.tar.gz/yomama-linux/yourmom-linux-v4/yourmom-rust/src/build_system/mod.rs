use std::fs;
use crate::errors::Result;

#[derive(Debug)]
pub struct YourDadConfig {
    pub sources: Vec<String>,
    pub output: String,
    pub optimization: u8,
    pub c_libs: Vec<String>,
    pub momjoke_files: Vec<String>,
}

impl YourDadConfig {
    /// Parse a .yourdad file
    ///
    /// Format:
    ///   sources: ["main.yourmom", "lib.yourmom"]
    ///   output: my_program
    ///   optimization: 2
    ///   c_libs: ["m", "pthread"]
    ///   momjoke: "jksmpl.momjoke"
    pub fn parse(path: &str) -> Result<Self> {
        let content = fs::read_to_string(path)?;

        let mut sources = Vec::new();
        let mut output = "a.out".to_string();
        let mut optimization: u8 = 2;
        let mut c_libs = vec!["m".to_string()];
        let mut momjoke_files = vec!["jksmpl.momjoke".to_string()];

        for line in content.lines() {
            let line = line.trim();

            // Skip comments and blank lines
            if line.is_empty() || line.starts_with('#') || line.starts_with("//") {
                continue;
            }

            if let Some(val) = strip_key(line, "sources:") {
                sources = parse_string_array(val);
            } else if let Some(val) = strip_key(line, "output:") {
                output = unquote(val.trim()).to_string();
            } else if let Some(val) = strip_key(line, "optimization:") {
                optimization = val.trim().parse().unwrap_or(2);
            } else if let Some(val) = strip_key(line, "c_libs:") {
                c_libs = parse_string_array(val);
            } else if let Some(val) = strip_key(line, "momjoke:") {
                let f = unquote(val.trim()).to_string();
                if !momjoke_files.contains(&f) {
                    momjoke_files.push(f);
                }
            }
        }

        if sources.is_empty() {
            sources.push("main.yourmom".to_string());
        }

        Ok(Self { sources, output, optimization, c_libs, momjoke_files })
    }

    /// Generate GCC flags from config
    pub fn gcc_flags(&self) -> Vec<String> {
        let mut flags = vec![
            format!("-O{}", self.optimization),
            "-I.".to_string(),
        ];
        for lib in &self.c_libs {
            flags.push(format!("-l{}", lib));
        }
        flags
    }
}

// ── helpers ──────────────────────────────────────────────────────────────────

fn strip_key<'a>(line: &'a str, key: &str) -> Option<&'a str> {
    line.strip_prefix(key)
}

/// Parse ["a", "b", "c"] into vec!["a", "b", "c"]
fn parse_string_array(s: &str) -> Vec<String> {
    let s = s.trim().trim_start_matches('[').trim_end_matches(']');
    s.split(',')
        .map(|item| unquote(item.trim()).to_string())
        .filter(|s| !s.is_empty())
        .collect()
}

/// Strip surrounding quotes from a string token
fn unquote(s: &str) -> &str {
    s.trim_matches('"').trim_matches('\'')
}
