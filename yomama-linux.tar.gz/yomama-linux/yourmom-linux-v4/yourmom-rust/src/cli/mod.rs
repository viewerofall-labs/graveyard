use colored::Colorize;
use crate::errors::Result;
use crate::lexer::ShortcutMap;
use crate::build_system::YourDadConfig;

pub fn childmake(input: &str, output: Option<&str>) -> Result<()> {
    println!("{}", "🤰 Hell yeah, mama got pregnant (compilation started)...".yellow());

    let output_name = output.unwrap_or("yourmom_program");
    let shortcuts = ShortcutMap::default_stdlib();

    let source = std::fs::read_to_string(input)
        .map_err(|_| crate::errors::YourMomError::FileNotFound(input.to_string()))?;

    crate::runtime::write_runtime()?;
    crate::compile_to_binary(&source, output_name, &shortcuts)?;

    println!("{}", format!("👶 Fuck yeah! Birth successful — binary: {}", output_name).green().bold());
    Ok(())
}

pub fn abortion(deep: bool) -> Result<()> {
    println!("{}", "🗑️  Aborting that shit — cleaning build artifacts...".yellow());

    let _ = std::fs::remove_file("output.c");
    let _ = std::fs::remove_file("yourmom_program");
    let _ = std::fs::remove_file("a.out");

    if deep {
        println!("{}", "Deep cleaning all quantum crap too...".yellow());
        // Remove quantum runtime caches
    }

    println!("{}", "✅ Abortion complete — that shit is gone".green());
    Ok(())
}

pub fn family_tree(project: &str) -> Result<()> {
    println!("{}", format!("👨‍👩‍👧‍👦 Family tree for: {} (what a goddamn mess)", project).cyan());

    let config = YourDadConfig::parse(project)?;
    println!("  output:       {}", config.output);
    println!("  optimization: O{}", config.optimization);
    println!("  sources:");
    for s in &config.sources {
        println!("    - {}", s);
    }
    println!("  c_libs:");
    for l in &config.c_libs {
        println!("    - {}", l);
    }
    println!("  momjoke files:");
    for m in &config.momjoke_files {
        println!("    - {}", m);
    }

    Ok(())
}

pub fn divorce(binary: &str) -> Result<()> {
    println!("{}", format!("💔 Divorcing from that bastard binary: {}", binary).yellow());

    std::fs::remove_file(binary)?;

    println!("{}", "✅ Divorce finalized — good fucking riddance".green());
    Ok(())
}

pub fn deadbeat(project: &str) -> Result<()> {
    println!("{}", "🔍 Checking for deadbeat dependencies, those lazy asses...".yellow());

    let config = YourDadConfig::parse(project)?;
    let mut deadbeats = 0;

    for lib in &config.c_libs {
        // Check if any source actually references the lib (basic heuristic)
        let referenced = config.sources.iter().any(|src| {
            std::fs::read_to_string(src)
                .map(|content| content.contains(lib.as_str()))
                .unwrap_or(false)
        });
        if !referenced {
            println!("  💀 {} — unused deadbeat lib, cut that bastard", lib.yellow());
            deadbeats += 1;
        }
    }

    if deadbeats == 0 {
        println!("{}", "✅ No deadbeats found — damn miracle".green());
    } else {
        println!("{}", format!("Found {} deadbeat(s) — handle your shit", deadbeats).red());
    }
    Ok(())
}

pub fn custody_list() -> Result<()> {
    println!("{}", "📋 Current .momjoke custody — these bitches:".cyan());

    // TODO: List loaded .momjoke files
    println!("  - jksmpl.momjoke");

    Ok(())
}

pub fn custody_add(file: &str) -> Result<()> {
    println!("{}", format!("➕ Adding {} to custody — one more shit to deal with", file).green());

    // TODO: Add .momjoke to project

    Ok(())
}

pub fn custody_remove(file: &str) -> Result<()> {
    println!("{}", format!("➖ Removing {} from custody — bye bitch", file).yellow());

    // TODO: Remove .momjoke from project

    Ok(())
}

pub fn run(file: &str) -> Result<()> {
    println!("{}", "🏃 Compiling and running that shit...".yellow());

    // Compile
    childmake(file, Some("temp_binary"))?;

    // Run
    let status = std::process::Command::new("./temp_binary")
        .status()?;

    // Cleanup
    let _ = std::fs::remove_file("temp_binary");

    if !status.success() {
        println!("{}", "💀 Oh fuck — runtime family drama occurred".red().bold());
    }

    Ok(())
}
