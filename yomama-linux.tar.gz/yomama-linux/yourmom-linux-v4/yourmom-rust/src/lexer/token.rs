use std::fmt;

#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    // Keywords
    Yo,
    YoMamaSoFat,       // println
    YoMamaSoDumb,      // panic
    YoMamaSoUgly,      // unsafe
    MamaMain,
    MamaSaid,          // if
    MamaLied,          // else
    MamaKeepsSaying,   // while
    DidYourMom,        // return
    DoingYourMom,      // call
    YoDaddy,           // struct (future)

    // Quantum types
    YoMamaInTwoPlaces, // superposition keyword
    IntAll,            // int_all
    RealAll,           // real_all
    RationalAll,       // rational_all
    IrrationalAll,     // irrational_all
    ImaginaryAll,      // imaginary_all

    // New quantum / exotic types
    Heisenberg,        // heisenberg(...)
    QuaternionAll,     // quaternion_all
    TransfiniteAll,    // transfinite_all
    QuantumSort,       // quantum_sort(...)
    EntangledWith,     // entangled_with

    // New control flow
    MamaSaidMaybe,     // Schrodinger's if
    MamaForgot,        // goto
    YoDaddyIssues,     // try
    MamaCaught,        // catch

    // New print / assert
    YoMamaSoLoud,      // uppercase print
    YoMamaSoParanoid,  // random assertion

    // Lazy
    YoMamaSoLazy,      // lazy evaluation

    // Meta / macros
    YoMamaSoMeta,      // macro definition / rewrite_self

    // Literals
    Identifier(String),
    StringLit(String),
    Number(i64),

    // Operators
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    Eq,
    EqEq,
    NotEq,
    Lt,
    Gt,
    LtEq,
    GtEq,
    Pipe,  // | for quantum superposition

    // Delimiters
    LParen,
    RParen,
    LBrace,
    RBrace,
    LBracket,
    RBracket,
    Comma,
    Semicolon,
    Colon,

    // Special
    Eof,
}

impl fmt::Display for Token {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Token::Identifier(s) => write!(f, "Identifier({})", s),
            Token::StringLit(s)  => write!(f, "String(\"{}\")", s),
            Token::Number(n)     => write!(f, "Number({})", n),
            _ => write!(f, "{:?}", self),
        }
    }
}
