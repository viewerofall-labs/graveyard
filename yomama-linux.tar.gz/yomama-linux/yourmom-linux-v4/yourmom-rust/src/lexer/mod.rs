mod token;
mod shortcuts;

pub use token::Token;
pub use shortcuts::ShortcutMap;

use crate::errors::{Result, YourMomError};

pub struct Lexer<'a> {
    input: Vec<char>,
    pos: usize,
    shortcuts: &'a ShortcutMap,
}

impl<'a> Lexer<'a> {
    pub fn new(source: &str, shortcuts: &'a ShortcutMap) -> Self {
        Self {
            input: source.chars().collect(),
            pos: 0,
            shortcuts,
        }
    }

    pub fn tokenize(&mut self) -> Result<Vec<Token>> {
        let mut tokens = Vec::new();

        while !self.is_at_end() {
            loop {
                let before = self.pos;
                self.skip_whitespace();
                self.skip_comments();
                if self.pos == before { break; }
            }

            if self.is_at_end() {
                break;
            }

            tokens.push(self.next_token()?);
        }

        tokens.push(Token::Eof);
        Ok(tokens)
    }

    fn next_token(&mut self) -> Result<Token> {
        let c = self.peek();

        if c == '"' {
            return self.read_string();
        }
        if c.is_ascii_digit() {
            return self.read_number();
        }
        if c.is_alphabetic() || c == '_' {
            return self.read_identifier();
        }

        let c = self.advance();
        match c {
            '+' => Ok(Token::Plus),
            '-' => Ok(Token::Minus),
            '*' => Ok(Token::Star),
            '/' => Ok(Token::Slash),
            '%' => Ok(Token::Percent),
            '|' => Ok(Token::Pipe),
            ',' => Ok(Token::Comma),
            ';' => Ok(Token::Semicolon),
            ':' => Ok(Token::Colon),
            '(' => Ok(Token::LParen),
            ')' => Ok(Token::RParen),
            '{' => Ok(Token::LBrace),
            '}' => Ok(Token::RBrace),
            '[' => Ok(Token::LBracket),
            ']' => Ok(Token::RBracket),
            '=' => {
                if self.peek() == '=' {
                    self.advance();
                    Ok(Token::EqEq)
                } else {
                    Ok(Token::Eq)
                }
            }
            '!' => {
                if self.peek() == '=' {
                    self.advance();
                    Ok(Token::NotEq)
                } else {
                    Err(YourMomError::LexerOverflow)
                }
            }
            '<' => {
                if self.peek() == '=' {
                    self.advance();
                    Ok(Token::LtEq)
                } else {
                    Ok(Token::Lt)
                }
            }
            '>' => {
                if self.peek() == '=' {
                    self.advance();
                    Ok(Token::GtEq)
                } else {
                    Ok(Token::Gt)
                }
            }
            _ => Err(YourMomError::LexerOverflow),
        }
    }

    fn read_string(&mut self) -> Result<Token> {
        self.advance(); // consume opening "
        let mut s = String::new();
        while !self.is_at_end() && self.peek() != '"' {
            if self.peek() == '\\' {
                self.advance();
                match self.advance() {
                    'n' => s.push('\n'),
                    't' => s.push('\t'),
                    '"' => s.push('"'),
                    '\\' => s.push('\\'),
                    c => { s.push('\\'); s.push(c); }
                }
            } else {
                s.push(self.advance());
            }
        }
        if !self.is_at_end() {
            self.advance(); // consume closing "
        }
        Ok(Token::StringLit(s))
    }

    fn read_number(&mut self) -> Result<Token> {
        let mut s = String::new();
        while !self.is_at_end() && self.peek().is_ascii_digit() {
            s.push(self.advance());
        }
        let n: i64 = s.parse().map_err(|_| YourMomError::LexerOverflow)?;
        Ok(Token::Number(n))
    }

    fn read_identifier(&mut self) -> Result<Token> {
        let mut s = String::new();
        while !self.is_at_end() && (self.peek().is_alphanumeric() || self.peek() == '_') {
            s.push(self.advance());
        }

        let s = self.shortcuts.expand(&s);

        let token = match s.as_str() {
            "yo"                    => Token::Yo,
            "yo_mama_so_fat"        => Token::YoMamaSoFat,
            "yo_mama_so_dumb"       => Token::YoMamaSoDumb,
            "yo_mama_so_ugly"       => Token::YoMamaSoUgly,
            "mama_main"             => Token::MamaMain,
            "mama_said"             => Token::MamaSaid,
            "mama_lied"             => Token::MamaLied,
            "mama_keeps_saying"     => Token::MamaKeepsSaying,
            "did_your_mom"          => Token::DidYourMom,
            "doing_your_mom"        => Token::DoingYourMom,
            "yo_daddy"              => Token::YoDaddy,
            "yo_mama_in_two_places" => Token::YoMamaInTwoPlaces,
            "int_all"               => Token::IntAll,
            "real_all"              => Token::RealAll,
            "rational_all"          => Token::RationalAll,
            "irrational_all"        => Token::IrrationalAll,
            "imaginary_all"         => Token::ImaginaryAll,
            // New tokens
            "heisenberg"            => Token::Heisenberg,
            "quaternion_all"        => Token::QuaternionAll,
            "transfinite_all"       => Token::TransfiniteAll,
            "quantum_sort"          => Token::QuantumSort,
            "entangled_with"        => Token::EntangledWith,
            "mama_said_maybe"       => Token::MamaSaidMaybe,
            "mama_forgot"           => Token::MamaForgot,
            "yo_daddy_issues"       => Token::YoDaddyIssues,
            "mama_caught"           => Token::MamaCaught,
            "yo_mama_so_loud"       => Token::YoMamaSoLoud,
            "yo_mama_so_paranoid"   => Token::YoMamaSoParanoid,
            "yo_mama_so_lazy"       => Token::YoMamaSoLazy,
            "yo_mama_so_meta"       => Token::YoMamaSoMeta,
            _                       => Token::Identifier(s),
        };

        Ok(token)
    }

    fn skip_whitespace(&mut self) {
        while !self.is_at_end() && self.peek().is_whitespace() {
            self.advance();
        }
    }

    fn skip_comments(&mut self) {
        if self.peek() == '/' && self.peek_ahead(1) == '/' {
            while !self.is_at_end() && self.peek() != '\n' {
                self.advance();
            }
        }
    }

    fn peek(&self) -> char {
        if self.is_at_end() {
            '\0'
        } else {
            self.input[self.pos]
        }
    }

    fn peek_ahead(&self, offset: usize) -> char {
        let idx = self.pos + offset;
        if idx >= self.input.len() {
            '\0'
        } else {
            self.input[idx]
        }
    }

    fn advance(&mut self) -> char {
        let c = self.peek();
        self.pos += 1;
        c
    }

    fn is_at_end(&self) -> bool {
        self.pos >= self.input.len()
    }
}
