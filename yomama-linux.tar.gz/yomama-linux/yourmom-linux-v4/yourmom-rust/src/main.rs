use clap::{Parser, Subcommand};
use colored::Colorize;
use yourmom::cli;

#[derive(Parser)]
#[command(name = "yourmom")]
#[command(about = "VQ — Version 3: Quantum. The most cursed fucking language in existence.", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Compile .yourmom files (daddy knocked up the source)
    #[command(alias = "build")]
    Childmake {
        /// Path to .yourmom file or .yourdad project
        #[arg(value_name = "FILE")]
        input: String,
        
        /// Output binary name
        #[arg(short, long)]
        output: Option<String>,
    },
    
    /// Clean build artifacts (abort the build)
    Abortion {
        /// Also remove quantum runtime cache
        #[arg(long)]
        deep: bool,
    },
    
    /// Show dependency tree (family tree)
    #[command(name = "family-tree")]
    FamilyTree {
        /// Path to .yourdad file
        project: String,
    },
    
    /// Remove binary (divorce from executable)
    Divorce {
        /// Binary to remove
        binary: String,
    },
    
    /// Check for unused dependencies (deadbeat check)
    Deadbeat {
        /// Path to .yourdad file
        project: String,
    },
    
    /// Manage .momjoke imports (custody battle)
    Custody {
        /// List, add, or remove .momjoke files
        #[command(subcommand)]
        action: CustodyAction,
    },
    
    /// Run compiled program directly
    Run {
        /// .yourmom file to compile and run
        file: String,
    },
    
    /// Start REPL (TODO: future feature)
    Repl,
}

#[derive(Subcommand)]
enum CustodyAction {
    /// List loaded .momjoke files
    List,
    /// Add a .momjoke dependency
    Add { file: String },
    /// Remove a .momjoke dependency  
    Remove { file: String },
}

fn main() {
    let cli = Cli::parse();
    
    let result = match cli.command {
        Commands::Childmake { input, output } => {
            cli::childmake(&input, output.as_deref())
        }
        Commands::Abortion { deep } => {
            cli::abortion(deep)
        }
        Commands::FamilyTree { project } => {
            cli::family_tree(&project)
        }
        Commands::Divorce { binary } => {
            cli::divorce(&binary)
        }
        Commands::Deadbeat { project } => {
            cli::deadbeat(&project)
        }
        Commands::Custody { action } => {
            match action {
                CustodyAction::List => cli::custody_list(),
                CustodyAction::Add { file } => cli::custody_add(&file),
                CustodyAction::Remove { file } => cli::custody_remove(&file),
            }
        }
        Commands::Run { file } => {
            cli::run(&file)
        }
        Commands::Repl => {
            println!("{}", "REPL not implemented yet (coming soon!)".yellow());
            Ok(())
        }
    };
    
    if let Err(e) = result {
        eprintln!("{} {}", "💀".red(), e.to_string().as_str().red());
        std::process::exit(1);
    }
}
