mod ast;

pub use ast::{Ast, AstNode, BinOp, Expr, Function, MacroDef, Stmt};

use crate::lexer::Token;
use crate::errors::{Result, YourMomError};
use std::collections::HashSet;

pub struct Parser {
    tokens: Vec<Token>,
    pos: usize,
    quantum_vars: HashSet<String>,
    float_quantum_vars: HashSet<String>,
    rational_quantum_vars: HashSet<String>,
    irrational_quantum_vars: HashSet<String>,
    imaginary_quantum_vars: HashSet<String>,
    heisenberg_vars: HashSet<String>,
    quaternion_vars: HashSet<String>,
    transfinite_vars: HashSet<String>,
    entangled_vars: HashSet<String>,
    lazy_vars: HashSet<String>,
    macros: Vec<MacroDef>,
}

impl Parser {
    pub fn new(tokens: Vec<Token>) -> Self {
        Self {
            tokens,
            pos: 0,
            quantum_vars: HashSet::new(),
            float_quantum_vars: HashSet::new(),
            rational_quantum_vars: HashSet::new(),
            irrational_quantum_vars: HashSet::new(),
            imaginary_quantum_vars: HashSet::new(),
            heisenberg_vars: HashSet::new(),
            quaternion_vars: HashSet::new(),
            transfinite_vars: HashSet::new(),
            entangled_vars: HashSet::new(),
            lazy_vars: HashSet::new(),
            macros: Vec::new(),
        }
    }

    pub fn parse(&mut self) -> Result<Ast> {
        let mut functions = Vec::new();

        while !self.is_at_end() {
            match self.peek().clone() {
                Token::YoMamaSoMeta => {
                    // top-level macro definition
                    let mdef = self.parse_macro_def()?;
                    self.macros.push(mdef);
                }
                Token::Yo => functions.push(self.parse_function()?),
                _ => { self.advance(); }
            }
        }

        Ok(Ast {
            functions,
            quantum_vars: self.quantum_vars.clone(),
            float_quantum_vars: self.float_quantum_vars.clone(),
            rational_quantum_vars: self.rational_quantum_vars.clone(),
            irrational_quantum_vars: self.irrational_quantum_vars.clone(),
            imaginary_quantum_vars: self.imaginary_quantum_vars.clone(),
            heisenberg_vars: self.heisenberg_vars.clone(),
            quaternion_vars: self.quaternion_vars.clone(),
            transfinite_vars: self.transfinite_vars.clone(),
            entangled_vars: self.entangled_vars.clone(),
            lazy_vars: self.lazy_vars.clone(),
            macros: self.macros.clone(),
        })
    }

    // ── macro definition (top-level) ─────────────────────────────────────────

    fn parse_macro_def(&mut self) -> Result<MacroDef> {
        self.expect(Token::YoMamaSoMeta)?;

        // check for rewrite_self — that's a statement, not a macro def
        // rewrite_self is handled at statement level; here we only parse actual defs
        let name = self.consume_identifier()?;
        self.expect(Token::LParen)?;

        let mut params = Vec::new();
        while !matches!(self.peek(), Token::RParen | Token::Eof) {
            params.push(self.consume_identifier()?);
            if matches!(self.peek(), Token::Comma) { self.advance(); }
        }
        self.expect(Token::RParen)?;
        self.expect(Token::Eq)?;

        // Collect body tokens until newline / end of expression
        // Simple: collect as string representations until we hit a structural token
        // We'll collect the rest of the "line" worth: just one expression's tokens
        let mut body_tokens = Vec::new();
        // Collect until we see a token that would terminate the definition
        // Strategy: collect tokens of the expression on this line
        loop {
            match self.peek() {
                Token::Eof | Token::YoMamaSoMeta | Token::MamaMain | Token::Yo => break,
                Token::LBrace => break,
                _ => {
                    let t = self.advance();
                    body_tokens.push(format!("{:?}", t));
                    // Stop after RParen if we opened one
                    if body_tokens.len() > 50 { break; }
                }
            }
        }

        Ok(MacroDef { name, params, body_tokens })
    }

    // ── function ────────────────────────────────────────────────────────────

    fn parse_function(&mut self) -> Result<Function> {
        self.expect(Token::Yo)?;
        let name = self.consume_function_name()?;
        self.expect(Token::LParen)?;

        let mut params = Vec::new();
        while !matches!(self.peek(), Token::RParen | Token::Eof) {
            params.push(self.consume_identifier()?);
            if matches!(self.peek(), Token::Comma) { self.advance(); }
        }

        self.expect(Token::RParen)?;
        self.expect(Token::LBrace)?;

        let mut body = Vec::new();
        while !matches!(self.peek(), Token::RBrace | Token::Eof) {
            if let Some(stmt) = self.parse_statement()? {
                body.push(stmt);
            }
        }

        self.expect(Token::RBrace)?;
        Ok(Function { name, params, body })
    }

    // ── statements ──────────────────────────────────────────────────────────

    fn parse_statement(&mut self) -> Result<Option<Stmt>> {
        match self.peek().clone() {
            Token::Yo               => Ok(Some(self.parse_var_decl()?)),
            Token::YoMamaSoFat      => Ok(Some(self.parse_print()?)),
            Token::MamaSaid         => Ok(Some(self.parse_if()?)),
            Token::MamaSaidMaybe    => Ok(Some(self.parse_schrodinger_if()?)),
            Token::MamaKeepsSaying  => Ok(Some(self.parse_while()?)),
            Token::DidYourMom       => Ok(Some(self.parse_return()?)),
            Token::DoingYourMom     => Ok(Some(self.parse_call_stmt()?)),
            Token::YoMamaSoUgly     => Ok(Some(self.parse_unsafe()?)),
            Token::MamaForgot       => Ok(Some(self.parse_goto()?)),
            Token::YoDaddyIssues    => Ok(Some(self.parse_try_catch()?)),
            Token::YoMamaSoLoud     => Ok(Some(self.parse_print_loud()?)),
            Token::YoMamaSoParanoid => Ok(Some(self.parse_paranoid()?)),
            Token::YoMamaSoMeta     => Ok(Some(self.parse_rewrite_self_stmt()?)),
            // Identifier followed by Colon = label
            Token::Identifier(_) if self.peek_ahead_is(1, &Token::Colon) => {
                Ok(Some(self.parse_label()?))
            }
            Token::Identifier(_) if self.peek_ahead_is(1, &Token::Eq) => {
                Ok(Some(self.parse_assignment()?))
            }
            _ => { self.advance(); Ok(None) }
        }
    }

    fn parse_var_decl(&mut self) -> Result<Stmt> {
        self.expect(Token::Yo)?;
        let name = self.consume_identifier()?;
        self.expect(Token::Eq)?;
        let value = self.parse_expression()?;

        match &value {
            Expr::Superposition(_) | Expr::IntAll => {
                self.quantum_vars.insert(name.clone());
            }
            Expr::RealAll => {
                self.float_quantum_vars.insert(name.clone());
            }
            Expr::RationalAll => {
                self.rational_quantum_vars.insert(name.clone());
            }
            Expr::IrrationalAll => {
                self.irrational_quantum_vars.insert(name.clone());
            }
            Expr::ImaginaryAll => {
                self.imaginary_quantum_vars.insert(name.clone());
            }
            Expr::HeisenbergOf(_) => {
                self.heisenberg_vars.insert(name.clone());
            }
            Expr::QuaternionAll => {
                self.quaternion_vars.insert(name.clone());
            }
            Expr::TransfiniteAll => {
                self.transfinite_vars.insert(name.clone());
            }
            Expr::EntangledWith(_) => {
                self.entangled_vars.insert(name.clone());
            }
            Expr::LazyExpr(_) => {
                self.lazy_vars.insert(name.clone());
            }
            Expr::QuantumSort(_) => {
                self.quantum_vars.insert(name.clone());
            }
            _ => {}
        }

        Ok(Stmt::VarDecl { name, value })
    }

    fn parse_assignment(&mut self) -> Result<Stmt> {
        let name = self.consume_identifier()?;
        self.expect(Token::Eq)?;
        let value = self.parse_expression()?;
        Ok(Stmt::Assignment { name, value })
    }

    fn parse_print(&mut self) -> Result<Stmt> {
        self.expect(Token::YoMamaSoFat)?;
        self.expect(Token::LParen)?;

        if let Token::StringLit(s) = self.peek().clone() {
            self.advance();
            self.expect(Token::RParen)?;
            return Ok(Stmt::PrintStr(s));
        }

        let expr = self.parse_expression()?;
        self.expect(Token::RParen)?;
        Ok(Stmt::PrintExpr(expr))
    }

    fn parse_print_loud(&mut self) -> Result<Stmt> {
        self.expect(Token::YoMamaSoLoud)?;
        self.expect(Token::LParen)?;
        if let Token::StringLit(s) = self.peek().clone() {
            self.advance();
            self.expect(Token::RParen)?;
            return Ok(Stmt::PrintLoud(s));
        }
        // Also accept expression that is a string
        Err(YourMomError::SyntaxError(
            "yo_mama_so_loud expects a string literal argument, you dumb bastard".into()
        ))
    }

    fn parse_paranoid(&mut self) -> Result<Stmt> {
        self.expect(Token::YoMamaSoParanoid)?;
        self.expect(Token::LParen)?;
        let expr = self.parse_expression()?;
        self.expect(Token::RParen)?;
        Ok(Stmt::Paranoid(expr))
    }

    fn parse_if(&mut self) -> Result<Stmt> {
        self.expect(Token::MamaSaid)?;
        let condition = self.parse_expression()?;
        self.expect(Token::LBrace)?;
        let then_block = self.parse_block()?;
        self.expect(Token::RBrace)?;

        let mut else_block = Vec::new();
        if matches!(self.peek(), Token::MamaLied) {
            self.advance();
            self.expect(Token::LBrace)?;
            else_block = self.parse_block()?;
            self.expect(Token::RBrace)?;
        }

        Ok(Stmt::If { condition, then_block, else_block })
    }

    fn parse_schrodinger_if(&mut self) -> Result<Stmt> {
        self.expect(Token::MamaSaidMaybe)?;
        self.expect(Token::LBrace)?;
        let then_block = self.parse_block()?;
        self.expect(Token::RBrace)?;

        let mut else_block = Vec::new();
        if matches!(self.peek(), Token::MamaLied) {
            self.advance();
            self.expect(Token::LBrace)?;
            else_block = self.parse_block()?;
            self.expect(Token::RBrace)?;
        }

        Ok(Stmt::SchrodingerIf { then_block, else_block })
    }

    fn parse_while(&mut self) -> Result<Stmt> {
        self.expect(Token::MamaKeepsSaying)?;
        let condition = self.parse_expression()?;
        self.expect(Token::LBrace)?;
        let body = self.parse_block()?;
        self.expect(Token::RBrace)?;
        Ok(Stmt::While { condition, body })
    }

    fn parse_return(&mut self) -> Result<Stmt> {
        self.expect(Token::DidYourMom)?;
        let value = self.parse_expression()?;
        Ok(Stmt::Return(value))
    }

    fn parse_call_stmt(&mut self) -> Result<Stmt> {
        self.expect(Token::DoingYourMom)?;
        let name = self.consume_identifier()?;
        self.expect(Token::LParen)?;
        let args = self.parse_args()?;
        self.expect(Token::RParen)?;
        Ok(Stmt::FunctionCall { name, args })
    }

    fn parse_unsafe(&mut self) -> Result<Stmt> {
        self.expect(Token::YoMamaSoUgly)?;
        self.expect(Token::LBrace)?;

        let mut asm_code = Vec::new();
        let mut body = Vec::new();

        while !matches!(self.peek(), Token::RBrace | Token::Eof) {
            if let Token::Identifier(ref s) = self.peek().clone() {
                if s == "__asm__" {
                    self.advance();
                    self.expect(Token::LParen)?;
                    if let Token::StringLit(code) = self.advance() {
                        asm_code.push(code);
                    }
                    self.expect(Token::RParen)?;
                    continue;
                }
            }
            if let Some(stmt) = self.parse_statement()? {
                body.push(stmt);
            }
        }

        self.expect(Token::RBrace)?;
        Ok(Stmt::UnsafeBlock { asm_code, body })
    }

    fn parse_goto(&mut self) -> Result<Stmt> {
        self.expect(Token::MamaForgot)?;
        let label = self.consume_identifier()?;
        Ok(Stmt::GotoStmt { label })
    }

    fn parse_label(&mut self) -> Result<Stmt> {
        let name = self.consume_identifier()?;
        self.expect(Token::Colon)?;
        Ok(Stmt::LabelStmt { name })
    }

    fn parse_try_catch(&mut self) -> Result<Stmt> {
        self.expect(Token::YoDaddyIssues)?;
        self.expect(Token::LBrace)?;
        let try_block = self.parse_block()?;
        self.expect(Token::RBrace)?;

        let mut catch_block = Vec::new();
        if matches!(self.peek(), Token::MamaCaught) {
            self.advance();
            self.expect(Token::LBrace)?;
            catch_block = self.parse_block()?;
            self.expect(Token::RBrace)?;
        }

        Ok(Stmt::TryCatch { try_block, catch_block })
    }

    fn parse_rewrite_self_stmt(&mut self) -> Result<Stmt> {
        self.expect(Token::YoMamaSoMeta)?;
        // expect: rewrite_self("filename")
        let name = self.consume_identifier()?;
        if name == "rewrite_self" {
            self.expect(Token::LParen)?;
            if let Token::StringLit(path) = self.peek().clone() {
                self.advance();
                self.expect(Token::RParen)?;
                return Ok(Stmt::RewriteSelf(path));
            }
            return Err(YourMomError::SyntaxError(
                "rewrite_self expects a string path, goddamn it".into()
            ));
        }
        // Otherwise it's a macro def inside a block — treat as no-op for now
        Ok(Stmt::GotoStmt { label: "__noop__".to_string() })
    }

    fn parse_block(&mut self) -> Result<Vec<Stmt>> {
        let mut stmts = Vec::new();
        while !matches!(self.peek(), Token::RBrace | Token::Eof) {
            if let Some(s) = self.parse_statement()? {
                stmts.push(s);
            }
        }
        Ok(stmts)
    }

    // ── expressions ─────────────────────────────────────────────────────────

    fn parse_expression(&mut self) -> Result<Expr> {
        let left = self.parse_primary()?;

        // Quantum superposition: a | b | c
        if matches!(self.peek(), Token::Pipe) {
            let mut values = vec![left];
            while matches!(self.peek(), Token::Pipe) {
                self.advance();
                values.push(self.parse_primary()?);
            }
            return Ok(Expr::Superposition(values));
        }

        self.parse_binop(left)
    }

    fn parse_binop(&mut self, mut left: Expr) -> Result<Expr> {
        loop {
            let op = match self.peek() {
                Token::Plus    => BinOp::Add,
                Token::Minus   => BinOp::Sub,
                Token::Star    => BinOp::Mul,
                Token::Slash   => BinOp::Div,
                Token::Percent => BinOp::Mod,
                Token::EqEq    => BinOp::Eq,
                Token::NotEq   => BinOp::NotEq,
                Token::Lt      => BinOp::Lt,
                Token::Gt      => BinOp::Gt,
                Token::LtEq    => BinOp::LtEq,
                Token::GtEq    => BinOp::GtEq,
                _              => break,
            };
            self.advance();
            let right = self.parse_primary()?;
            left = Expr::BinaryOp { op, left: Box::new(left), right: Box::new(right) };
        }
        Ok(left)
    }

    fn parse_primary(&mut self) -> Result<Expr> {
        match self.peek().clone() {
            Token::StringLit(s)  => { self.advance(); Ok(Expr::String(s)) }
            Token::Number(n)     => { self.advance(); Ok(Expr::Number(n)) }
            Token::LParen => {
                self.advance();
                let expr = self.parse_expression()?;
                self.expect(Token::RParen)?;
                Ok(expr)
            }
            Token::DoingYourMom => {
                self.advance();
                let name = self.consume_identifier()?;
                self.expect(Token::LParen)?;
                let args = self.parse_args()?;
                self.expect(Token::RParen)?;
                Ok(Expr::FunctionCall { name, args })
            }
            Token::IntAll        => { self.advance(); Ok(Expr::IntAll) }
            Token::RealAll       => { self.advance(); Ok(Expr::RealAll) }
            Token::RationalAll   => { self.advance(); Ok(Expr::RationalAll) }
            Token::IrrationalAll => { self.advance(); Ok(Expr::IrrationalAll) }
            Token::ImaginaryAll  => { self.advance(); Ok(Expr::ImaginaryAll) }
            Token::QuaternionAll => { self.advance(); Ok(Expr::QuaternionAll) }
            Token::TransfiniteAll => { self.advance(); Ok(Expr::TransfiniteAll) }

            Token::Heisenberg => {
                self.advance();
                self.expect(Token::LParen)?;
                // parse superposition values: a | b | c
                let mut values = Vec::new();
                values.push(self.parse_primary()?);
                while matches!(self.peek(), Token::Pipe) {
                    self.advance();
                    values.push(self.parse_primary()?);
                }
                self.expect(Token::RParen)?;
                Ok(Expr::HeisenbergOf(values))
            }

            Token::QuantumSort => {
                self.advance();
                self.expect(Token::LParen)?;
                let inner = self.parse_expression()?;
                self.expect(Token::RParen)?;
                Ok(Expr::QuantumSort(Box::new(inner)))
            }

            Token::EntangledWith => {
                self.advance();
                let var_name = self.consume_identifier()?;
                Ok(Expr::EntangledWith(var_name))
            }

            Token::YoMamaSoLazy => {
                self.advance();
                self.expect(Token::LParen)?;
                let inner = self.parse_expression()?;
                self.expect(Token::RParen)?;
                Ok(Expr::LazyExpr(Box::new(inner)))
            }

            Token::Identifier(name) => {
                self.advance();
                // Check if this is a macro invocation
                if matches!(self.peek(), Token::LParen) {
                    let macro_name = name.clone();
                    // Check against known macros
                    let macro_exists = self.macros.iter().any(|m| m.name == macro_name);
                    if macro_exists {
                        self.advance(); // consume LParen
                        let args = self.parse_args()?;
                        self.expect(Token::RParen)?;
                        // For simplicity: expand to a function call with the same name
                        // (macro expansion is done in codegen via name lookup)
                        return Ok(Expr::FunctionCall { name: macro_name, args });
                    }
                    // Otherwise treat as regular function call
                    self.advance(); // consume LParen
                    let args = self.parse_args()?;
                    self.expect(Token::RParen)?;
                    return Ok(Expr::FunctionCall { name, args });
                }
                Ok(Expr::Variable(name))
            }
            t => Err(YourMomError::SyntaxError(
                format!("what the fuck is this token in expression: {:?}", t)
            ))
        }
    }

    fn parse_args(&mut self) -> Result<Vec<Expr>> {
        let mut args = Vec::new();
        while !matches!(self.peek(), Token::RParen | Token::Eof) {
            args.push(self.parse_expression()?);
            if matches!(self.peek(), Token::Comma) { self.advance(); }
        }
        Ok(args)
    }

    // ── helpers ─────────────────────────────────────────────────────────────

    fn consume_function_name(&mut self) -> Result<String> {
        match self.advance() {
            Token::MamaMain      => Ok("mama_main".to_string()),
            Token::Identifier(s) => Ok(s),
            t => Err(YourMomError::SyntaxError(
                format!("expected function name, got {:?} — you dumb bastard", t)
            ))
        }
    }

    fn consume_identifier(&mut self) -> Result<String> {
        match self.advance() {
            Token::Identifier(s) => Ok(s),
            t => Err(YourMomError::SyntaxError(
                format!("expected identifier, got {:?} — what the fuck", t)
            ))
        }
    }

    fn peek_ahead_is(&self, offset: usize, token: &Token) -> bool {
        let idx = self.pos + offset;
        if idx >= self.tokens.len() { return false; }
        std::mem::discriminant(&self.tokens[idx]) == std::mem::discriminant(token)
    }

    fn peek(&self) -> &Token {
        &self.tokens[self.pos]
    }

    fn advance(&mut self) -> Token {
        let token = self.tokens[self.pos].clone();
        self.pos += 1;
        token
    }

    fn expect(&mut self, expected: Token) -> Result<()> {
        let token = self.advance();
        if std::mem::discriminant(&token) != std::mem::discriminant(&expected) {
            return Err(YourMomError::SyntaxError(
                format!("expected {:?}, got {:?} — goddamn it", expected, token)
            ));
        }
        Ok(())
    }

    fn is_at_end(&self) -> bool {
        matches!(self.peek(), Token::Eof)
    }
}
