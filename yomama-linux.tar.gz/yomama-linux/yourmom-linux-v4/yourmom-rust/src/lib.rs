pub mod lexer;
pub mod parser;
pub mod codegen;
pub mod errors;
pub mod build_system;
pub mod cli;
pub mod runtime;

// Re-export common types
pub use errors::{YourMomError, Result};
pub use lexer::{Lexer, Token};
pub use parser::{Parser, Ast};
pub use codegen::Codegen;

/// Compile a single .yourmom file to C
pub fn compile_to_c(source: &str, shortcuts: &lexer::ShortcutMap) -> Result<String> {
    let mut lexer = Lexer::new(source, shortcuts);
    let tokens = lexer.tokenize()?;
    
    let mut parser = Parser::new(tokens);
    let ast = parser.parse()?;
    
    let mut codegen = Codegen::new();
    let c_code = codegen.generate(&ast)?;
    
    Ok(c_code)
}

/// Compile and link to binary
pub fn compile_to_binary(
    source: &str,
    output: &str,
    shortcuts: &lexer::ShortcutMap,
) -> Result<()> {
    let c_code = compile_to_c(source, shortcuts)?;
    
    // Write C file
    std::fs::write("output.c", &c_code)?;
    
    // Call gcc
    let status = std::process::Command::new("gcc")
        .args(&["-I.", "output.c", "-o", output, "-lm"])
        .status()?;
    
    if !status.success() {
        return Err(errors::YourMomError::GccFailed);
    }
    
    Ok(())
}
