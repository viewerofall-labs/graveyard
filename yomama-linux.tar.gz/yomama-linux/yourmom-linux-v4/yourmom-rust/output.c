#include "quantum_runtime.h"

int main() {
    _quantum_init_errors();
    printf("Hello, World!\n");
    return 0;
}

