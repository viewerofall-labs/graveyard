#!/usr/bin/env bash
# Generate the GRUB background PNG for the yomama theme
# Requires: imagemagick
# Output: iso/grub/themes/yomama/background.png

OUT="$(dirname "$0")/../iso/grub/themes/yomama/background.png"

if ! command -v convert &>/dev/null; then
    echo "imagemagick not found — install it: sudo pacman -S imagemagick"
    exit 1
fi

# GRUB requires 8-bit RGB PNG — no alpha, no 16-bit
magick -size 1920x1080 \
    gradient:"#0d0019-#220044" \
    -fill "#1a003a" \
    -draw "rectangle 480,260 1440,820" \
    -fill none \
    -stroke "#5500aa" \
    -strokewidth 2 \
    -draw "rectangle 480,260 1440,820" \
    -depth 8 \
    -define png:color-type=2 \
    "$OUT"

echo "Generated: $OUT"
