# Quantum Cookie Clicker TUI

**A terminal-based cookie clicker with quantum mechanics**

*"Yo mama so quantum, she exists in multiple bakeries simultaneously"*

---

## Features

- 🍪 **Quantum Click Boost** - Random 1-10x multiplier
- 🎲 **Heisenberg Mystery Boxes** - Unpredictable cookie rewards
- 🔮 **Superposition Mechanics** - Quantum randomness in every click
- 📈 **4 Upgrades** - Grandmas, Quantum Ovens, Heisenberg Bakeries, Entangled Farms
- ⚡ **60 FPS TUI** - Smooth terminal rendering
- 💜 **Purple TWM Aesthetic** - Deep purple boxes and UI

---

## Controls

| Key | Action |
|-----|--------|
| `SPACE` | Click cookie (gain cookies) |
| `1` | Buy Grandma (+1 cookie/sec) |
| `2` | Buy Quantum Oven (+5 cookie/sec, +1 click power) |
| `3` | Buy Heisenberg Bakery (+20 cookie/sec) |
| `4` | Buy Entangled Farm (+100 cookie/sec) |
| `Q` | Quantum Click Boost (random 1-10x) |
| `M` | Mystery Box (random cookies) |
| `q` | Quit game |

---

## Building

### Prerequisites

- .yourmom compiler installed
- GCC
- Linux/Unix terminal

### Build Steps

```bash
# Make build script executable
chmod +x build.sh

# Build
./build.sh

# Run
./quantum_clicker
```

### Manual Build

```bash
# Transpile .yourmom files
yourmom childmake quantum_clicker.yourmom
yourmom childmake terminal.yourmom

# Compile C wrapper
gcc -c terminal_wrapper.c -o terminal_wrapper.o

# Link everything
gcc quantum_clicker.c terminal.c terminal_wrapper.o -o quantum_clicker -lm -O2

# Run
./quantum_clicker
```

---

## File Structure

```
quantum_clicker/
├── quantum_clicker.yourmom    # Main game logic
├── terminal.yourmom           # TUI/terminal utilities
├── terminal_wrapper.c         # C wrapper for terminal I/O
├── quantum_clicker.yourdad    # Build configuration
├── build.sh                   # Build script
└── README.md                  # This file
```

---

## Gameplay

### Starting Out

1. Press `SPACE` to click the cookie
2. Each click gives you 1 cookie (base click power)
3. Save up 10 cookies to buy your first Grandma

### Upgrades

**Grandma** (10 cookies, scales by 15%)
- +1 cookie per second
- Basic auto-generation

**Quantum Oven** (100 cookies)
- +5 cookies per second
- +1 click power (makes clicks better)

**Heisenberg Bakery** (1,000 cookies)
- +20 cookies per second
- Named after quantum uncertainty

**Entangled Farm** (10,000 cookies)
- +100 cookies per second
- Quantum entanglement for massive production

### Quantum Mechanics

**Quantum Click Boost (`Q`)**
- Each click has a random multiplier
- Can be 1x, 2x, 3x, 5x, or 10x
- Uses quantum superposition: `1 | 2 | 3 | 5 | 10`

**Mystery Box (`M`)**
- Heisenberg variable: re-randomizes every time
- Might give 0, might give 500
- Pure quantum uncertainty

---

## Code Highlights

### Quantum Superposition

```yourmom
yo quantum_click_boost() {
    // Random click boost from quantum fluctuation
    yo boost = 1 | 2 | 3 | 5 | 10
    did_your_mom boost
}
```

### Heisenberg Variable

```yourmom
yo quantum_mystery_cookies() {
    // Heisenberg's uncertainty - changes every read
    yo mystery = heisenberg(0 | 0 | 0 | 50 | 100 | 500)
    did_your_mom mystery
}
```

### Cost Scaling

```yourmom
yo calculate_cost(base, count) {
    // Cost scales by 15% per purchase
    yo cost = base
    yo i = 0
    mama_keeps_saying i < count {
        cost = cost * 115 / 100
        i = i + 1
    }
    did_your_mom cost
}
```

---

## .yourdad Build System

This project uses `.yourdad` build configuration:

```yourdad
daddy_says_build_this {
    sources: ["quantum_clicker.yourmom", "terminal.yourmom"]
    output: "quantum_clicker"
    optimization: 2
}

daddy_says_use_protection {
    c_libs: ["m"]
    c_files: ["terminal_wrapper.c"]
}

daddy_says_wear_these_hats {
    "jksmpl.momjoke"
    "qol.momjoke"
}
```

**Benefits:**
- Multi-file project organization
- C library integration
- Standard library imports
- Centralized configuration

---

## Technical Details

### Terminal Control

Uses ANSI escape sequences for:
- Cursor positioning
- Screen clearing
- Alternate buffer
- Raw mode input

### Rendering

- Box drawing with Unicode characters (┌─┐│└┘)
- 60 FPS game loop with `sleep_ms(16)`
- Non-blocking input handling
- Automatic cookie generation based on frame count

### Performance

- Native C speed (compiled via .yourmom → C → GCC)
- Minimal memory footprint
- Smooth 60 FPS rendering
- Instant input response

---

## Why This Is Cool

1. **Multi-file .yourmom project** - Shows how to organize larger programs
2. **Build system example** - Demonstrates `.yourdad` configuration
3. **C interop** - Terminal wrapper shows how to integrate C libraries
4. **TUI rendering** - Proves .yourmom can do terminal UIs
5. **Quantum mechanics** - Actually uses language features meaningfully
6. **Complete game** - Fully playable, not just a tech demo

---

## Extending the Game

### Add More Upgrades

```yourmom
yo superposition_factory = 0
yo superposition_cost = 100000

yo buy_superposition_factory() {
    yo cost = dym calculate_cost(superposition_cost, superposition_factory)
    mama_said cookies >= cost {
        cookies = cookies - cost
        superposition_factory = superposition_factory + 1
        cookies_per_second = cookies_per_second + 500
        did_your_mom 1
    }
    did_your_mom 0
}
```

### Add Achievements

```yourmom
yo total_clicks = 0
yo achievement_unlocked = 0

mama_said total_clicks >= 1000 {
    mama_said achievement_unlocked == 0 {
        yo_mama_so_loud("ACHIEVEMENT: CLICK MASTER!")
        achievement_unlocked = 1
    }
}
```

### Add Prestige System

```yourmom
yo prestige_level = 0

yo prestige() {
    mama_said cookies >= 1000000 {
        prestige_level = prestige_level + 1
        cookies = 0
        click_power = click_power * 2
        // Reset upgrades but keep multiplier
    }
}
```

---

## License

WTFPL - Do what the fuck you want

---

## Credits

Built with:
- .yourmom programming language
- Terminal/ANSI escape codes
- Quantum mechanics
- Your mom jokes

**"Yo mama so TUI, she lives in the terminal"**
