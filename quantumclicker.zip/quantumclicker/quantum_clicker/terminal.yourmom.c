#include "quantum_runtime.h"
#include <ncurses.h>

int init_terminal() {
    system("stty -echo raw");
}

int reset_terminal() {
    system("stty echo -raw");
}

int hide_cursor() {
}

int show_cursor() {
}

int clear_screen() {
}

int move_cursor(int x, int y) {
}

int draw_box(int x, int y, int width, int height) {
    move_cursor(x, y);
    int i = 0;
    while (((i < width) - 2)) {
        i = (i + 1);
    }
    int row = 1;
    while (((row < height) - 1)) {
        move_cursor(x, (y + row));
        move_cursor(((x + width) - 1), (y + row));
        row = (row + 1);
    }
    move_cursor(x, ((y + height) - 1));
    i = 0;
    while (((i < width) - 2)) {
        i = (i + 1);
    }
}

int draw_horizontal_line(int x, int y, int length) {
    move_cursor(x, y);
    int i = 0;
    while ((i < length)) {
        i = (i + 1);
    }
}

int get_key_nonblock() {
    int key = getchar_nonblock();
    return key;
}

int wait_for_key() {
    getchar();
}

int sleep_ms(int ms) {
    usleep((ms * 1000));
}

