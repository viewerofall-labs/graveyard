// terminal_wrapper.c - C wrappers for terminal I/O
// These functions are called from .yourmom code

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
#include <sys/select.h>

// Terminal state
static struct termios orig_termios;

// Get single character non-blocking
int getchar_nonblock(void) {
    struct timeval tv;
    fd_set fds;
    
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    
    select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv);
    
    if (FD_ISSET(STDIN_FILENO, &fds)) {
        return getchar();
    }
    
    return -1;
}

// Sleep microseconds
void usleep_wrapper(unsigned int usec) {
    usleep(usec);
}

// System command wrapper
int system_wrapper(const char* cmd) {
    return system(cmd);
}
