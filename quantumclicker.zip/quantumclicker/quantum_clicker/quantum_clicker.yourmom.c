#include "quantum_runtime.h"
#include <ncurses.h>

int init_terminal() {
    printf("\x1b[?1049h");
    printf("\x1b[?25l");
    system("stty -echo raw");
}

int reset_terminal() {
    printf("\x1b[?1049l");
    printf("\x1b[?25h");
    system("stty echo -raw");
}

int hide_cursor() {
    printf("\x1b[?25l");
}

int show_cursor() {
    printf("\x1b[?25h");
}

int clear_screen() {
    printf("\x1b[2J");
    printf("\x1b[H");
}

int move_cursor(int x, int y) {
    printf("\x1b[%d;%dH", y, x);
}

int draw_box(int x, int y, int width, int height) {
    move_cursor(x, y);
    printf("\xe2\x94\x8c");
    int i = 0;
    while ((i < (width - 2))) {
        printf("\xe2\x94\x80");
        i = (i + 1);
    }
    printf("\xe2\x94\x90");
    int row = 1;
    while ((row < (height - 1))) {
        move_cursor(x, (y + row));
        printf("\xe2\x94\x82");
        move_cursor(((x + width) - 1), (y + row));
        printf("\xe2\x94\x82");
        row = (row + 1);
    }
    move_cursor(x, ((y + height) - 1));
    printf("\xe2\x94\x94");
    i = 0;
    while ((i < (width - 2))) {
        printf("\xe2\x94\x80");
        i = (i + 1);
    }
    printf("\xe2\x94\x98");
}

int get_key_nonblock() {
    int key = getchar_nonblock();
    return key;
}

int wait_for_key() {
    getchar();
}

int sleep_ms(int ms) {
    usleep_wrapper((ms * 1000));
}

int quantum_click_boost() {
    quantum_heisenberg boost = HEISENBERG(1, 2, 3, 5, 10);
    return _quantum_heisenberg_get(&boost);
}

int quantum_mystery_cookies() {
    quantum_heisenberg mystery = HEISENBERG(0, 0, 0, 50, 100, 500);
    return _quantum_heisenberg_get(&mystery);
}

int calculate_cost(int base, int count) {
    int cost = base;
    int i = 0;
    while ((i < count)) {
        cost = ((cost * 115) / 100);
        i = (i + 1);
    }
    return cost;
}

int main() {
    _quantum_init_errors();
    int cookies = 0;
    int cookies_per_second = 0;
    int click_power = 1;
    int grandmas = 0;
    int quantum_ovens = 0;
    int heisenberg_bakeries = 0;
    int entangled_farms = 0;
    int grandma_cost = 10;
    int oven_cost = 100;
    int bakery_cost = 1000;
    int farm_cost = 10000;
    int frame_count = 0;
    init_terminal();
    hide_cursor();
    _quantum_shout("WELCOME TO QUANTUM COOKIE CLICKER!");
    printf("\n");
    printf("Press any key to start...\n");
    wait_for_key();
    int running = 1;
    while ((running == 1)) {
        clear_screen();
        draw_box(0, 0, 80, 3);
        move_cursor(25, 1);
        _quantum_shout("QUANTUM COOKIE CLICKER");
        move_cursor(22, 2);
        printf("btw I use .yourmom (press 'q' to quit)");
        draw_box(0, 4, 80, 8);
        move_cursor(30, 5);
        printf("Cookie Clicker");
        move_cursor(30, 6);
        printf("[PRESS SPACE]");
        move_cursor(5, 10);
        printf("Total Cookies: %d", cookies);
        move_cursor(50, 10);
        printf("Per Second: %d", cookies_per_second);
        draw_box(0, 12, 80, 12);
        move_cursor(28, 13);
        printf("=== UPGRADES ===");
        int g_cost = calculate_cost(grandma_cost, grandmas);
        move_cursor(5, 15);
        if ((cookies >= g_cost)) {
            printf("[1] Grandma (+1/s)");
        } else {
            printf("[ ] Grandma (+1/s)");
        }
        move_cursor(35, 15);
        printf("Cost: %d", g_cost);
        move_cursor(55, 15);
        printf("Owned: %d", grandmas);
        int o_cost = calculate_cost(oven_cost, quantum_ovens);
        move_cursor(5, 17);
        if ((cookies >= o_cost)) {
            printf("[2] Quantum Oven (+5/s, +1 click)");
        } else {
            printf("[ ] Quantum Oven (+5/s, +1 click)");
        }
        move_cursor(35, 17);
        printf("Cost: %d", o_cost);
        move_cursor(55, 17);
        printf("Owned: %d", quantum_ovens);
        int b_cost = calculate_cost(bakery_cost, heisenberg_bakeries);
        move_cursor(5, 19);
        if ((cookies >= b_cost)) {
            printf("[3] Heisenberg Bakery (+20/s)");
        } else {
            printf("[ ] Heisenberg Bakery (+20/s)");
        }
        move_cursor(35, 19);
        printf("Cost: %d", b_cost);
        move_cursor(55, 19);
        printf("Owned: %d", heisenberg_bakeries);
        int f_cost = calculate_cost(farm_cost, entangled_farms);
        move_cursor(5, 21);
        if ((cookies >= f_cost)) {
            printf("[4] Entangled Farm (+100/s)");
        } else {
            printf("[ ] Entangled Farm (+100/s)");
        }
        move_cursor(35, 21);
        printf("Cost: %d", f_cost);
        move_cursor(55, 21);
        printf("Owned: %d", entangled_farms);
        draw_box(0, 24, 80, 5);
        move_cursor(28, 25);
        printf("=== QUANTUM ZONE ===");
        move_cursor(5, 27);
        printf("[Q] Quantum Click Boost (random 1-10x)");
        move_cursor(50, 27);
        printf("[M] Mystery Box (?? cookies)");
        move_cursor(0, 29);
        printf("Click power: %d", click_power);
        frame_count = (frame_count + 1);
        if ((frame_count >= 60)) {
            cookies = (cookies + cookies_per_second);
            frame_count = 0;
        }
        int key = get_key_nonblock();
        if ((key == 32)) {
            int qboost = quantum_click_boost();
            cookies = (cookies + (click_power * qboost));
        }
        if ((key == 49)) {
            if ((cookies >= g_cost)) {
                cookies = (cookies - g_cost);
                grandmas = (grandmas + 1);
                cookies_per_second = (cookies_per_second + 1);
            }
        }
        if ((key == 50)) {
            if ((cookies >= o_cost)) {
                cookies = (cookies - o_cost);
                quantum_ovens = (quantum_ovens + 1);
                cookies_per_second = (cookies_per_second + 5);
                click_power = (click_power + 1);
            }
        }
        if ((key == 51)) {
            if ((cookies >= b_cost)) {
                cookies = (cookies - b_cost);
                heisenberg_bakeries = (heisenberg_bakeries + 1);
                cookies_per_second = (cookies_per_second + 20);
            }
        }
        if ((key == 52)) {
            if ((cookies >= f_cost)) {
                cookies = (cookies - f_cost);
                entangled_farms = (entangled_farms + 1);
                cookies_per_second = (cookies_per_second + 100);
            }
        }
        if ((key == 113)) {
            int qboost = quantum_click_boost();
            cookies = (cookies + ((click_power * qboost) * 5));
        }
        if ((key == 109)) {
            int mystery_gain = quantum_mystery_cookies();
            cookies = (cookies + mystery_gain);
        }
        if ((key == 27)) {
            running = 0;
        }
        sleep_ms(16);
    }
    show_cursor();
    reset_terminal();
    clear_screen();
    _quantum_shout("THANKS FOR PLAYING!");
    printf("Final cookies: %d
", cookies);
    printf("Cookies per second: %d
", cookies_per_second);
    return 0;
}

