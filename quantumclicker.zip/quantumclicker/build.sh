#!/bin/bash
# build.sh - Build Quantum Cookie Clicker

set -e

echo "🍪 Building Quantum Cookie Clicker..."
echo ""

# Step 1: Compile .yourmom files to C
echo "Step 1: Transpiling .yourmom → C..."
yourmom childmake quantum_clicker.yourmom
yourmom childmake terminal.yourmom

# This creates: quantum_clicker.c and terminal.c

# Step 2: Compile C wrapper
echo "Step 2: Compiling terminal wrapper..."
gcc -c terminal_wrapper.c -o terminal_wrapper.o

# Step 3: Link everything together
echo "Step 3: Linking..."
gcc quantum_clicker.c terminal.c terminal_wrapper.o -o quantum_clicker -lm -O2

# Step 4: Cleanup intermediate files
echo "Step 4: Cleanup..."
rm -f quantum_clicker.c terminal.c terminal_wrapper.o quantum_runtime.h

echo ""
echo "✅ Build complete!"
echo "Run with: ./quantum_clicker"
