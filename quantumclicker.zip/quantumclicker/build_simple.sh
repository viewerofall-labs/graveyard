#!/bin/bash
# build_simple.sh - Build simple version (no terminal control needed)

set -e

echo "🍪 Building Quantum Cookie Clicker (Simple Version)..."
echo ""

echo "Compiling quantum_clicker_simple.yourmom..."
yourmom childmake quantum_clicker_simple.yourmom -o quantum_clicker_simple

echo ""
echo "✅ Build complete!"
echo "Run with: ./quantum_clicker_simple"
echo ""
echo "Controls:"
echo "  c = Click cookie"
echo "  1 = Buy Grandma"
echo "  2 = Buy Quantum Oven"
echo "  3 = Buy Heisenberg Bakery"
echo "  q = Quantum Boost"
echo "  m = Mystery Box"
echo "  x = Exit"
